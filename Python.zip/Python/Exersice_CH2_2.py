name = input ("enter your name :")
reverse =  (name [-1::-1])
print (f"reverse of you name is {name [-1::-1]}")