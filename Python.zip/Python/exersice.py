# Print these following lines *******
# this is \\ double backslash
# these are /\/\/\/\/\ mountains
# he is       awesome (use escape sequence instead of manual spaces)
# \"\n\t \' (print this as an output)
print ("this is \\\\ double backslash")
print ("these are /\/\/\/\/\ mountains")
print ("he is \t\t\t\tawesome")
print (" \\\" \\n \\t \\\' ")