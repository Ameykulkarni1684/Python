print("Hello World")
print('Hello 'World' world')
print('Hello "World" world')