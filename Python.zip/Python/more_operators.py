name = "kulkarni"
name = name + "04"
name += "05"
print (name)
age = 23
age *= 2
print (age)