# #*******Summary******
# #Print Function
# print ("hello \"hello\' ")
# #escape sequence
# print("line A \tline B")
# print ("line B")
# #escape sequence as normal text
# print ("line A \\n line B")
# peint (r"line A \n line B")
# #Python as calculator
# Print (2+3*3)
# print (2-3)
# print (2*3)
# Print (4/2) # Float division 
# print (4//2) #integer division 
# print (2**3**2) # exponent right to left
# #Parenthese left to right 
# #Exponent right to left
# print ((2+3) *4/2)
# #Variables
# # name = "Amey"
# # name = 123
# # naming rules for Variables
# # Convention for variable naming
# user_one = "Amey" # snake case writing 
# userOne = "Amey" # camel case writing
