#len() function
name = "Amey Kulkarni"
print (len(name))

#lower() method 
print (name.lower())

# upper() funtion 
print (name.upper())
#title() method 
print (name.title())
#count() method
print (name.count("K"))