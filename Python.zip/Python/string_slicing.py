lang = "python"
#print (lang[4])
# print (lang[2:4])
# print (lang[-3:6])
# print (lang[:])
print (lang[:3])
