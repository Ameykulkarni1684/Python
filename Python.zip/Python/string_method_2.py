#replace() method
#find() method

str = "she is beautiful and she is good dancer"
# print (string.replace("is","was",2))

is_pos1 = str.find("is") #is_pos1 = number
is_pos2 =str.find("is",is_pos1)
print(is_pos2)
is_pos3 = str.find("is",is_pos1 +1)
print(is_pos3)