#print (2+3*4)
#print (2/4)
#print(4/2) # floating point division 
#print (4//2) # integer division 
#print (2**3) # exponent 
#print (2**0.5) # square root
print (round (2**0.5,4)) # rounding off
print (3%2) # Modulo

