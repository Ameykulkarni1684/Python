name = "Amey"
age = "40"
print ("Hello" +"name" + "your age is"+str(age)) # ugly syntax
print ("hello {} your age is {}".format(name,age)) # python 3
print (f"hello {name} your age is {age}") # clean formatting in 3.6
print (f"hello {name} your age is {age + 2}")