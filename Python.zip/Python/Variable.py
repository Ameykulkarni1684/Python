number1 =2
print (number1)