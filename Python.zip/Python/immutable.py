#strings are immutable 
string = "string"
# (string[1]) = 'T' # there will be error as string is immutable
(string.replace('t','T'))
print (string)

