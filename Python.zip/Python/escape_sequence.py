#this is comment
print("line A \n line B") #\n is for new line
print ("name\tAmey") #\t is for tab
print ("This is backslash\\") #\\ to print backslash
print ("hell\blo") #ctrl + / to comment the line 
# output : Line A \n Line B
print ("Line A \\n Line B")
print ("Line A \\t Line B")
print ("this is double backslash \\\\")
# output : \" \'
print ("\\\"\\\'")