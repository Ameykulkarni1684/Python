#Script with a function to add two numbers and return the result. Use the function and show the input values and the result 
#Function to add two numbers
def add_number (num1,num2):
    sum_result = num1+num2
    return Sum_result
    #input from user
    number1 = float(input("Enter first number : "))
    number2 = float(input ("Enter Second number : "))
    #call the add_number Function 
    result = add_number (number1,number2)
    print(f"The Sum of the number {number1}and {number2}is:{result}")
