laungage = "python"

#position (index number)

print(laungage[2]) # start from 0
print (laungage[-1]) # from end it will be -1,-2