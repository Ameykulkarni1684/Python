# num1 = input("enter first number:")
# num2 = input("enter second number:")
# num3 = input("enter third number:")
#(int(num1) + int(num2) + int(num3)) /3
num1,num2,num3 = input("enter three numbers comma seperated:").split(",")
print (f"avg of three numbers: {(int(num1) + int(num2) + int(num3)) /3} ")